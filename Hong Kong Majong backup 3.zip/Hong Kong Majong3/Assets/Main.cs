using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using System.Collections;
using System.Linq;

public class Main : MonoBehaviour
{
    [Header("Pong UI")]
    [SerializeField] private GameObject yesButton;
    [SerializeField] private GameObject noButton;
    [SerializeField] private GameObject ThrowButton;
    public string Returns = "null";
    int PongCount;
    int index;
    public int CurrentTurn = 0;
    public static bool ThrowOut = false;
    public static string ThrowenOutTile;
    public static string YN = "null";
    public static string[] Hand = new string[14];
    public static string[] DiscardPile = new string[84];
    // Public so you can see/edit it in the Inspector
    public List<string> tiles = new List<string>()
    {
        // B1–B9
        "B1","B1","B1","B1",
        "B2","B2","B2","B2",
        "B3","B3","B3","B3",
        "B4","B4","B4","B4",
        "B5","B5","B5","B5",
        "B6","B6","B6","B6",
        "B7","B7","B7","B7",
        "B8","B8","B8","B8",
        "B9","B9","B9","B9",

        // C1–C9
        "C1","C1","C1","C1",
        "C2","C2","C2","C2",
        "C3","C3","C3","C3",
        "C4","C4","C4","C4",
        "C5","C5","C5","C5",
        "C6","C6","C6","C6",
        "C7","C7","C7","C7",
        "C8","C8","C8","C8",
        "C9","C9","C9","C9",

        // N1–N9
        "N1","N1","N1","N1",
        "N2","N2","N2","N2",
        "N3","N3","N3","N3",
        "N4","N4","N4","N4",
        "N5","N5","N5","N5",
        "N6","N6","N6","N6",
        "N7","N7","N7","N7",
        "N8","N8","N8","N8",
        "N9","N9","N9","N9",

        // Directions
        "NORTH","NORTH","NORTH","NORTH",
        "SOUTH","SOUTH","SOUTH","SOUTH",
        "EAST","EAST","EAST","EAST",
        "WEST","WEST","WEST","WEST",

        // W, Z, F
        "W","W","W","W",
        "Z","Z","Z","Z",
        "F","F","F","F"
    };

    void Start()
    {
        Application.targetFrameRate = 30;
        StartCoroutine(MainStart());
    }

    public void YES()
    {
        YN = "Y";
    }

    public void DISPLAYHAND()
    {
        for (int i = 0; i < 14; i++)
        {
            Debug.Log($"Tile{i}: {Hand[i]}");
        }
    }

    public void NO()
    {
        YN = "N";
    }

    public void ReadyToThrow()
    {
        ThrowOut = true;
    }

    System.Collections.IEnumerator PongCheck()
    {
        PongCount = 0;
        for (int i = 0; i < Hand.Length; i++)
        {
            if (Hand[i] == DiscardPile[CurrentTurn])
            {
                PongCount++; 
            } 
        }

        if (PongCount > 1)
        {
            yesButton.SetActive(true);
            noButton.SetActive(true);
            TM.SetMainText("Pong?");
            yield return new WaitUntil(() => YN != "null");
            if (YN == "Y")
            {
                for (int i = 0; i < Hand.Length; i++)
                {
                    if (Hand[i] == DiscardPile[CurrentTurn])
                    {
                        Hand[i] = "TAKEN";
                    } 
                }

                Hand[int.Parse(ThrowenOutTile) - 1] = DiscardPile[CurrentTurn];

                ITM[] itms = FindObjectsOfType<ITM>();
                for (int j = 0; j < itms.Length; j++)
                {
                    itms[j].UpdateTiles();
                }

                Hand[int.Parse(ThrowenOutTile) - 1] = "TAKEN";

                itms = FindObjectsOfType<ITM>();
                for (int j = 0; j < itms.Length; j++)
                {
                    itms[j].UpdateTiles();
                }

                Returns = "true";
            
            } else
            {
                Returns = "false";
            }

            yesButton.SetActive(false);
            noButton.SetActive(false);
            TM.SetMainText("");
            YN = "null";
        } else
        {
            Returns = "false";
        }
    }

    System.Collections.IEnumerator MainStart()
    {
        TM.SetMainText("");
        for (int i = 0; i < 14; i++) 
        {
            index = Random.Range(0, tiles.Count);
            Hand[i] = tiles[index];
            tiles.RemoveAt(index);
        }

        GameObject AniTile = GameObject.Find("AniTile");

        
        ITM[] itms = FindObjectsOfType<ITM>();
        for (int j = 0; j < itms.Length; j++)
        {
            itms[j].UpdateTiles();
        }
        ThrowButton.SetActive(true);
        yield return new WaitUntil(() => ThrowOut);
        ThrowButton.SetActive(false);
        TM.SetMainText("Pick a tile to remove");

        //Your first turn:
        yield return new WaitUntil(() => !ThrowOut);
        TM.SetMainText("");
        CurrentTurn++;
        AniTile.GetComponent<Renderer>().material = Resources.Load<Material>($"TileMaterials/{DiscardPile[CurrentTurn - 1]}");
        GameObject.Find("PutTile").GetComponent<Button>().onClick.Invoke();

        while(true) {

        for (int ID = 2; ID < 5; ID++)
        {
        yield return new WaitForSeconds(1f);
        AniTile.GetComponent<Renderer>().material = Resources.Load<Material>("TileMaterials/EMPTY");
        GameObject.Find($"{ID}G").GetComponent<Button>().onClick.Invoke();

        yield return new WaitForSeconds(1f);
        index = Random.Range(0, tiles.Count);
        AniTile.GetComponent<Renderer>().material = Resources.Load<Material>($"TileMaterials/{tiles[index]}");
        GameObject.Find($"{ID}P").GetComponent<Button>().onClick.Invoke();
        
        yield return new WaitForSeconds(1f);
        DiscardPile[CurrentTurn] = tiles[index];
        tiles.RemoveAt(index);

        Returns = "null";

        StartCoroutine(PongCheck());

        yield return new WaitUntil(() => Returns != "null");
        Debug.Log($"Pong: {Returns}");
        CurrentTurn++;
        if (Returns == "true")
        {
            break;
        }
        }

        if (Returns == "false")
        {
            //Your second turn
            yield return new WaitForSeconds(1f);
            index = Random.Range(0, tiles.Count);
            AniTile.GetComponent<Renderer>().material = Resources.Load<Material>($"TileMaterials/{tiles[index]}");
            GameObject.Find("GetTile").GetComponent<Button>().onClick.Invoke();

            yield return new WaitForSeconds(1f);
            Hand[int.Parse(ThrowenOutTile) - 1] = tiles[index];

            for (int j = 0; j < itms.Length; j++)
            {
                itms[j].UpdateTiles();
            }

            tiles.RemoveAt(index);
        }

        Returns = "null";
            

        ThrowButton.SetActive(true);
        yield return new WaitUntil(() => ThrowOut);
        ThrowButton.SetActive(false);
        TM.SetMainText("Pick a tile to remove");

        yield return new WaitUntil(() => !ThrowOut);
        TM.SetMainText("");
        CurrentTurn++;
        AniTile.GetComponent<Renderer>().material = Resources.Load<Material>($"TileMaterials/{DiscardPile[CurrentTurn - 1]}");
        GameObject.Find("PutTile").GetComponent<Button>().onClick.Invoke();

        }


    }
}
