using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

public class TileManager : MonoBehaviour
{   
    private Camera cam;
    private bool dragging;
    private float zDistance;

    void Awake()
    {
        cam = Camera.main;
    }

    void Update()
    {
        // Mouse press
        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            Ray ray = cam.ScreenPointToRay(Mouse.current.position.ReadValue());

            if (Physics.Raycast(ray, out RaycastHit hit))
            {
                if (hit.transform == transform)
                {
                    if (Main.Hand[int.Parse(gameObject.name) - 1] == "TAKEN")
                    {
                        dragging = true;
                        zDistance = cam.WorldToScreenPoint(transform.position).z;

                    } else {

                        if (!Main.ThrowOut)
                        {
                            dragging = true;
                            zDistance = cam.WorldToScreenPoint(transform.position).z;
                        } else
                        {
                            Main.ThrowenOutTile = gameObject.name;
                            Main.DiscardPile[System.Array.IndexOf(Main.DiscardPile, null)] = Main.Hand[int.Parse(gameObject.name) - 1];

                            Main.Hand[int.Parse(gameObject.name) - 1] = "EMPTY";

                            ITM[] itms = FindObjectsOfType<ITM>();
                            for (int j = 0; j < itms.Length; j++)
                            {
                                itms[j].UpdateTiles();
                            }

                            Main.ThrowOut = false;
                        }

                    }
                }
            }
        }

        // Mouse release
        if (Mouse.current.leftButton.wasReleasedThisFrame)
        {
            dragging = false;
        }

        // Dragging
        if (dragging)
        {
            Vector3 mousePos = Mouse.current.position.ReadValue();
            mousePos.z = zDistance;
            transform.position = cam.ScreenToWorldPoint(mousePos);
        }
    }
}
