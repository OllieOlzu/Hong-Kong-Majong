using UnityEngine;
using System.Collections.Generic;

public class RunOnStart : MonoBehaviour
{
    public static bool ThrowOut = false;
    public static string ThrowenOutTile;
    // Public so you can see/edit it in the Inspector
    public List<string> tiles = new List<string>()
    {
        // B1–B9
        "B1","B1","B1","B1",
        "B2","B2","B2","B2",
        "B3","B3","B3","B3",
        "B4","B4","B4","B4",
        "B5","B5","B5","B5",
        "B6","B6","B6","B6",
        "B7","B7","B7","B7",
        "B8","B8","B8","B8",
        "B9","B9","B9","B9",

        // C1–C9
        "C1","C1","C1","C1",
        "C2","C2","C2","C2",
        "C3","C3","C3","C3",
        "C4","C4","C4","C4",
        "C5","C5","C5","C5",
        "C6","C6","C6","C6",
        "C7","C7","C7","C7",
        "C8","C8","C8","C8",
        "C9","C9","C9","C9",

        // N1–N9
        "N1","N1","N1","N1",
        "N2","N2","N2","N2",
        "N3","N3","N3","N3",
        "N4","N4","N4","N4",
        "N5","N5","N5","N5",
        "N6","N6","N6","N6",
        "N7","N7","N7","N7",
        "N8","N8","N8","N8",
        "N9","N9","N9","N9",

        // Directions
        "NORTH","NORTH","NORTH","NORTH",
        "SOUTH","SOUTH","SOUTH","SOUTH",
        "EAST","EAST","EAST","EAST",
        "WEST","WEST","WEST","WEST",

        // W, Z, F
        "W","W","W","W",
        "Z","Z","Z","Z",
        "F","F","F","F"
    };

    void Start()
    {
        
        for (int i = 0; i < 13; i++) 
        {
            int index = Random.Range(0, tiles.Count);
            TTM.SetTileTex(i + 1, tiles[index]);
            tiles.RemoveAt(index);
        }

        ThrowOut = true;
        TM.SetMainText("Pick a tile to remove");


        
    }
}
