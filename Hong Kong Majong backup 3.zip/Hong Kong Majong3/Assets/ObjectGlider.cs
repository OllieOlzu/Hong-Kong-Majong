using UnityEngine;
using System.Collections;

public class ObjectGlider : MonoBehaviour
{
    [Header("Start Configuration")]
    public Vector3 startPosition;
    public Vector3 startRotationEuler;

    [Header("End Configuration")]
    public Vector3 endPosition;
    public Vector3 endRotationEuler;

    [Header("Settings")]
    public float duration = 2.0f;
    public bool startOnPlay = false;
    public bool hideAfterFinished = true; // The new toggle button
    public float DelayAtEnd = 1f; 

    void Start()
    {
        if (startOnPlay)
        {
            StartGlide();
        }
    }

    public void StartGlide()
    {
        // Ensure the object is visible when we start
        gameObject.SetActive(true);
        
        StopAllCoroutines();
        StartCoroutine(GlideRoutine());
    }

    private IEnumerator GlideRoutine()
    {
        Quaternion startRot = Quaternion.Euler(startRotationEuler);
        Quaternion endRot = Quaternion.Euler(endRotationEuler);

        // Snap to start
        transform.position = startPosition;
        transform.rotation = startRot;

        float elapsedTime = 0;

        while (elapsedTime < duration)
        {
            float t = elapsedTime / duration;
            
            transform.position = Vector3.Lerp(startPosition, endPosition, t);
            transform.rotation = Quaternion.Slerp(startRot, endRot, t);

            elapsedTime += Time.deltaTime;
            yield return null;
        }

        // Final alignment
        transform.position = endPosition;
        transform.rotation = endRot;

        // Hide the object if the toggle is checked
        if (hideAfterFinished)
        {
            yield return new WaitForSeconds(0.15f);
            gameObject.SetActive(false);
        }
    }
}