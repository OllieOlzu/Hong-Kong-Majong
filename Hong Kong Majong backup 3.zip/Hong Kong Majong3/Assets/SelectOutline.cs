using UnityEngine;
using UnityEngine.InputSystem;
using cakeslice;

public class SelectOutline : MonoBehaviour
{
    Outline currentOutline;

    void Update()
    {
        if (Mouse.current == null)
            return;

        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            Ray ray = Camera.main.ScreenPointToRay(Mouse.current.position.ReadValue());

            if (Physics.Raycast(ray, out RaycastHit hit))
            {
                Outline outline = hit.collider.GetComponent<Outline>();

                if (outline != null)
                {
                    if (currentOutline != null)
                        currentOutline.enabled = false;

                    outline.enabled = true;
                    currentOutline = outline;
                }
            }
            else
            {
                if (currentOutline != null)
                {
                    currentOutline.enabled = false;
                    currentOutline = null;
                }
            }
        }
    }
}
