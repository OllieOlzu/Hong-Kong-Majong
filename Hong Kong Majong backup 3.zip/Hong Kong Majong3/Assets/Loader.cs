using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Collections;

public class LoadingScreen : MonoBehaviour
{
    public Slider progressBar;
    public string sceneToLoad;

    void Start()
    {
        StartCoroutine(LoadScene());
    }

    IEnumerator LoadScene()
    {
        AsyncOperation op = SceneManager.LoadSceneAsync("HKM_Pro");
        op.allowSceneActivation = false;

        while (!op.isDone)
        {
            // Progress goes from 0 to 0.9
            float progress = Mathf.Clamp01(op.progress / 0.9f);
            progressBar.value = progress;

            // When loading is done
            if (op.progress >= 0.9f)
            {
                progressBar.value = 1f;
                yield return new WaitForSeconds(0.5f); // optional delay
                op.allowSceneActivation = true;
            }

            yield return null;
        }
    }
}
