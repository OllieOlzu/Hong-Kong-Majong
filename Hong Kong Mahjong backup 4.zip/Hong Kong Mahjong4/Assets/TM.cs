using TMPro;
using UnityEngine;

public class TM : MonoBehaviour
{
    private static TMP_Text _text;

    public static void SetMainText(string message)
    {
        _text = GameObject.Find("MainText").GetComponent<TMP_Text>();
        _text.text = message;
    }
}
