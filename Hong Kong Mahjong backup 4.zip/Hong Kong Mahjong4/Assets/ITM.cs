using UnityEngine;

public class ITM : MonoBehaviour
{
    Material tileMat;
    Texture2D tileTex;

    public void UpdateTiles()
    {
        string NameOfTile = Main.Hand[int.Parse(gameObject.name) - 1];
        if (NameOfTile[0] == 'T' && NameOfTile[1] == 'A' && NameOfTile[2] == 'K' && NameOfTile[3] == 'E' && NameOfTile[4] == 'N')
        {
            Debug.Log("Set transparecy");
            var m = GetComponent<Renderer>().material;
            Color newColor = m.color;
            newColor.a = 150f / 255f; 

            // Apply it back to the material
            m.color = newColor;
        } else
        {
            tileMat = Resources.Load<Material>(
            $"TileTextures/Tile{gameObject.name}"
            );

            if (tileMat == null)
            {
                Debug.LogError($"tileMat is null for {gameObject.name}. Check if Resources/TileTextures/Tile{gameObject.name} exists.");
                return;
            }
        
        
            tileTex = Resources.Load<Texture2D>(
                $"TileTextures/{Main.Hand[int.Parse(gameObject.name) - 1]}"
            );

            if (Main.Hand[int.Parse(gameObject.name) - 1] == "EMPTY")
            {
                GetComponent<MeshRenderer>().enabled = false;
            } else
            {
                GetComponent<MeshRenderer>().enabled = true;
            }

        
        
        
        
            if (tileTex == null)
            {
                Debug.LogError($"Texture not found: TileTextures/{Main.Hand[int.Parse(gameObject.name) - 1]}");
                return;
            }
        
            tileMat.SetTexture("_BaseMap", tileTex);
        }
    }
}
