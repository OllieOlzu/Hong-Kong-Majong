using UnityEngine;
using System.Collections;

public class CloneGrid10x10 : MonoBehaviour
{
    int CurrentDisgard = 0;
    public int width = 10;
    public int height = 10;
    public float spacingX = 1.5f;
    public float spacingZ = 1.5f;

    void Start()
    {
        StartCoroutine(CloneGrid());
    }

    IEnumerator CloneGrid()
    {
        Vector3 startPos = transform.position;
        GameObject lastClone = null; // Tracks the most recently created clone

        for (int z = 0; z < height; z++)
        {
            for (int x = 0; x < width; x++)
            {
                // Wait until there is a tile in the pile OR a delete command
                yield return new WaitUntil(() => Main.DiscardPile[CurrentDisgard] != null || Main.DeleteDisTile == "Y");

                if (Main.DeleteDisTile == "Y")
                {
                    Main.DeleteDisTile = "N";

                    if (lastClone != null)
                    {
                        // Hide ONLY the specific previous clone
                        lastClone.GetComponent<MeshRenderer>().enabled = false;
                    }

                    // Step back in the loop logic
                    x--; 
                    // Note: Be careful with x-- and z-- logic; 
                    // if x is 0, this might cause issues without additional checks.
                }
                else
                {
                    CurrentDisgard++;

                    Vector3 newPos = startPos
                        + Vector3.right * spacingX * x
                        + Vector3.forward * spacingZ * z;

                    // Create the new clone
                    lastClone = Instantiate(gameObject, newPos, transform.rotation);
                    
                    // Prevent the clone from running this same script recursively
                    if(lastClone.TryGetComponent<CloneGrid10x10>(out var script)) {
                        script.enabled = false;
                    }

                    // Set material and ENSURE renderer is enabled for this new clone
                    MeshRenderer renderer = lastClone.GetComponent<MeshRenderer>();
                    lastClone.GetComponent<Renderer>().material = Resources.Load<Material>($"TileMaterials/{Main.DiscardPile[CurrentDisgard - 1]}");
                    
                    renderer.enabled = true; 
                }
            }
        }
    }
}