using UnityEditor;
using UnityEngine;
using System.IO;

public class GenerateTileMaterials
{
    [MenuItem("Tools/Generate Tile Materials (URP)")]
    public static void Generate()
    {
        string textureFolder = "Assets/Resources/TileTextures";
        string materialFolder = "Assets/Resources/TileMaterials";

        // Ensure material folder exists
        if (!Directory.Exists(materialFolder))
        {
            Directory.CreateDirectory(materialFolder);
        }

        // Find URP/Lit shader
        Shader urpLit = Shader.Find("Universal Render Pipeline/Lit");
        if (urpLit == null)
        {
            Debug.LogError("URP/Lit shader not found. Is URP installed?");
            return;
        }

        // Find all textures
        string[] guids = AssetDatabase.FindAssets("t:Texture2D", new[] { textureFolder });

        foreach (string guid in guids)
        {
            string texturePath = AssetDatabase.GUIDToAssetPath(guid);
            Texture2D texture = AssetDatabase.LoadAssetAtPath<Texture2D>(texturePath);
            if (texture == null) continue;

            string name = Path.GetFileNameWithoutExtension(texturePath);
            string materialPath = $"{materialFolder}/{name}.mat";

            // Skip if material already exists
            if (File.Exists(materialPath))
                continue;

            // Create URP/Lit material
            Material mat = new Material(urpLit);

            // === MATCH YOUR INSPECTOR SETTINGS ===

            // Base Map
            mat.SetTexture("_BaseMap", texture);

            // Workflow: Metallic
            mat.SetFloat("_WorkflowMode", 1f); // 1 = Metallic

            // Surface Type: Opaque
            mat.SetFloat("_Surface", 0f); // 0 = Opaque

            // Render Face: Front
            mat.SetFloat("_Cull", (float)UnityEngine.Rendering.CullMode.Back);

            // Metallic & Smoothness defaults
            mat.SetFloat("_Metallic", 0f);
            mat.SetFloat("_Smoothness", 0.5f);

            // Receive Shadows (on by default, but explicit)
            mat.SetFloat("_ReceiveShadows", 1f);

            AssetDatabase.CreateAsset(mat, materialPath);
        }

        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();

        Debug.Log("URP tile materials generated!");
    }
}