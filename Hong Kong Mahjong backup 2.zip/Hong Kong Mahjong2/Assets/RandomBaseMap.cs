using UnityEngine;
using System.Collections.Generic;

public class RandomBaseMap : MonoBehaviour
{
    Material testMaterial;
    List<Texture2D> textures = new List<Texture2D>();

    void Start()
    {
        // Load material
        testMaterial = Resources.Load<Material>("TileTextures/Tile1");

        if (testMaterial == null)
        {
            Debug.LogError("TestMaterial not found in Resources/TileTextures");
            return;
        }

        // Load ALL textures in the folder
        Texture2D[] loadedTextures = Resources.LoadAll<Texture2D>("TileTextures");

        foreach (Texture2D tex in loadedTextures)
        {
            textures.Add(tex);
        }

        if (textures.Count == 0)
        {
            Debug.LogError("No PNG textures found in Resources/TileTextures");
            return;
        }

        InvokeRepeating(nameof(ChangeTexture), 0f, 1f);
    }

    void ChangeTexture()
    {
        Texture2D randomTex = textures[Random.Range(0, textures.Count)];

        // URP / HDRP
        testMaterial.SetTexture("_BaseMap", randomTex);

        // Built-in pipeline fallback
        testMaterial.SetTexture("_MainTex", randomTex);
    }
}
