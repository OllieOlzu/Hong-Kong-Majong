using UnityEngine;
using System.Collections;

public class CloneGrid10x10 : MonoBehaviour
{
    int CurrentDisgard = 0;
    public int width = 10;
    public int height = 10;
    public float spacingX = 1.5f;
    public float spacingZ = 1.5f;
    public float interval = 1f;

    void Start()
    {
        StartCoroutine(CloneGrid());
    }

    IEnumerator CloneGrid()
    {
        Vector3 startPos = transform.position;

        for (int z = 0; z < height; z++)
        {
            for (int x = 0; x < width; x++)
            {

                yield return new WaitUntil(() => Main.DiscardPile[CurrentDisgard] != null);
                CurrentDisgard++;

                Vector3 newPos = startPos
                    + Vector3.right * spacingX * x
                    + Vector3.forward * spacingZ * z;

                GameObject clone = Instantiate(gameObject, newPos, transform.rotation);
                clone.GetComponent<CloneGrid10x10>().enabled = false;

                clone.GetComponent<Renderer>().material = Resources.Load<Material>($"TileMaterials/{Main.DiscardPile[CurrentDisgard - 1]}");
                clone.GetComponent<MeshRenderer>().enabled = true;

                

                
                
                

            }
        }
    }
}
