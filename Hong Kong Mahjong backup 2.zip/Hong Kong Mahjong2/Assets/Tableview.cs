using UnityEngine;

public class Tableview : MonoBehaviour
{
    public Vector3 targetPosition = new Vector3(0f, 1.75f, 0.636f);
    public Vector3 targetRotation = new Vector3(90f, -180f, 0f);
    public float moveSpeed = 2f;
    public float rotateSpeed = 2f;

    private bool moveCamera = false;

    void Update()
    {
        if (!moveCamera) return;

        transform.position = Vector3.Lerp(
            transform.position,
            targetPosition,
            Time.deltaTime * moveSpeed
        );

        Quaternion targetRot = Quaternion.Euler(targetRotation);
        transform.rotation = Quaternion.Slerp(
            transform.rotation,
            targetRot,
            Time.deltaTime * rotateSpeed
        );
    }

    public void MoveCamera()
    {
        moveCamera = true;
    }
}
