using UnityEngine;

public class TTM : MonoBehaviour
{
    /// <summary>
    /// Sets TileX material's BaseMap to a texture from TileTextures
    /// </summary>
    /// <param name="tileNumber">1–13 (Tile1 → Tile13)</param>
    /// <param name="textureName">PNG name without extension (eg "W", "B5")</param>
    public static void SetTileTex(int tileNumber, string textureName)
    {
        // Load material: Tile1–Tile13
        Material tileMat = Resources.Load<Material>(
            $"TileTextures/Tile{tileNumber}"
        );

        // Load texture: W.png, B3.png, etc
        Texture2D tileTex = Resources.Load<Texture2D>(
            $"TileTextures/{textureName}"
        );

        if (tileTex == null)
        {
            Debug.LogError($"Texture {textureName}.png not found in TileTextures");
            return;
        }

        // URP Base Map
        tileMat.SetTexture("_BaseMap", tileTex);
    }
}
