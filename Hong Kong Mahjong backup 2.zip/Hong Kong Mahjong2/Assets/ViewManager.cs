using UnityEngine;

public class ViewManager : MonoBehaviour
{
    [Header("Hand View Settings")]
    public Vector3 handPos = new Vector3(0f, 0.75f, 1.75f);
    public Vector3 handRot = new Vector3(11f, -180f, 0f);

    [Header("Table View Settings")]
    public Vector3 tablePos = new Vector3(0f, 1.75f, 0.636f);
    public Vector3 tableRot = new Vector3(90f, -180f, 0f);

    [Header("Movement Settings")]
    public float moveSpeed = 2f;
    public float rotateSpeed = 2f;

    private Vector3 targetPos;
    private Quaternion targetRot;
    private bool isMoving = false;

    void Update()
    {
        if (!isMoving) return;

        // Use localPosition for relative movement
        transform.localPosition = Vector3.Lerp(
            transform.localPosition, 
            targetPos, 
            Time.deltaTime * moveSpeed
        );

        // Use localRotation for relative rotation
        transform.localRotation = Quaternion.Slerp(
            transform.localRotation, 
            targetRot, 
            Time.deltaTime * rotateSpeed
        );

        // Check distance based on localPosition
        if (Vector3.Distance(transform.localPosition, targetPos) < 0.001f && 
            Quaternion.Angle(transform.localRotation, targetRot) < 0.1f)
        {
            transform.localPosition = targetPos;
            transform.localRotation = targetRot;
            isMoving = false;
        }
    }

    public void MoveToHandView()
    {
        targetPos = handPos;
        targetRot = Quaternion.Euler(handRot);
        isMoving = true;
    }

    public void MoveToTableView()
    {
        targetPos = tablePos;
        targetRot = Quaternion.Euler(tableRot);
        isMoving = true;
    }
}